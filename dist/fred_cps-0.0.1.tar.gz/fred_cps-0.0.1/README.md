# Complementi di Probabilità e Statistica
## **Setup** ##
Se si utilizza windows occorre installare SQLite3  e inserire il path nelle variabili d'ambiente.

Per installare il package utilizzare l'url:
https://test.pypi.org/project/ProgettoCPS/0.0.1/
